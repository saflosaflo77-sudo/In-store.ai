import { useState, useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════
   IN-STORE AI  — Owner: You
   Tagline: "Know Your Queue. Grow Your Store."
   Brand: Warm amber + deep charcoal + cream white
   Vibe: Approachable, African-market energy, premium
═══════════════════════════════════════════════════════ */

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;0,9..144,900;1,9..144,400&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --amber:#F59E0B;--amber2:#D97706;--amber3:#FCD34D;
  --green:#10B981;--green2:#059669;
  --red:#EF4444;--orange:#F97316;
  --bg:#0C0A08;--bg2:#141210;--bg3:#1C1A17;
  --card:#1E1B17;--border:#2A2620;
  --text:#FAF7F2;--muted:#8A8070;--faint:#3A3630;
}
body{background:var(--bg);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif}
::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:var(--amber);border-radius:4px}
select,input{outline:none;appearance:none}
button{cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif}
@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes shimmer{0%{background-position:-600px 0}100%{background-position:600px 0}}
@keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
@keyframes glow{0%,100%{box-shadow:0 0 24px #F59E0B44}50%{box-shadow:0 0 48px #F59E0B88}}
@keyframes scan{0%{top:0}100%{top:100%}}
.fu1{animation:fadeUp .6s ease .05s both}
.fu2{animation:fadeUp .6s ease .15s both}
.fu3{animation:fadeUp .6s ease .25s both}
.fu4{animation:fadeUp .6s ease .35s both}
.fu5{animation:fadeUp .6s ease .45s both}
.float{animation:float 4s ease-in-out infinite}
.pulse{animation:pulse 2s infinite}
.glow-amber{animation:glow 3s infinite}
`;

// ── LOGO SVG ──────────────────────────────────────────
function Logo({ size = 36, withText = true }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
        <rect width="40" height="40" rx="10" fill="#F59E0B" />
        <rect x="8" y="8" width="10" height="10" rx="2" fill="#0C0A08" />
        <rect x="22" y="8" width="10" height="10" rx="2" fill="#0C0A08" opacity=".5" />
        <rect x="8" y="22" width="10" height="10" rx="2" fill="#0C0A08" opacity=".5" />
        <rect x="22" y="22" width="10" height="10" rx="2" fill="#0C0A08" />
        <circle cx="20" cy="20" r="4" fill="#F59E0B" stroke="#0C0A08" strokeWidth="2" />
      </svg>
      {withText && (
        <span style={{ fontFamily: "'Fraunces',serif", fontWeight: 900, fontSize: size * 0.58, color: "#FAF7F2", letterSpacing: "-0.5px", lineHeight: 1 }}>
          In<span style={{ color: "#F59E0B" }}>Store</span><span style={{ color: "#8A8070", fontWeight: 400, fontSize: size * 0.4 }}> AI</span>
        </span>
      )}
    </div>
  );
}

// ── QUEUE LEVEL ───────────────────────────────────────
function ql(s) {
  if (s <= 2) return { label: "Very Low",  color: "#10B981", bg: "#061a10", emoji: "🟢" };
  if (s <= 4) return { label: "Low",        color: "#34D399", bg: "#071a12", emoji: "🟢" };
  if (s <= 6) return { label: "Moderate",  color: "#F59E0B", bg: "#1a1000", emoji: "🟡" };
  if (s <= 8) return { label: "High",       color: "#F97316", bg: "#1a0a00", emoji: "🟠" };
  return              { label: "Very High", color: "#EF4444", bg: "#1a0606", emoji: "🔴" };
}

const PEAK = {
  Monday:    [1,1,1,1,1,1,1,3,5,6,7,7,8,7,6,6,7,8,7,5,4,2,1,1],
  Tuesday:   [1,1,1,1,1,1,1,3,5,6,7,7,8,7,6,6,7,8,7,5,4,2,1,1],
  Wednesday: [1,1,1,1,1,1,1,3,5,6,7,7,8,7,6,6,7,8,7,5,4,2,1,1],
  Thursday:  [1,1,1,1,1,1,1,3,5,7,8,8,9,8,7,7,8,9,8,6,4,2,1,1],
  Friday:    [1,1,1,1,1,1,1,4,6,8,9,9,10,9,8,8,9,10,9,7,5,3,2,1],
  Saturday:  [1,1,1,1,1,1,2,5,8,10,10,10,9,9,8,8,9,9,8,7,6,4,2,1],
  Sunday:    [1,1,1,1,1,1,2,4,6,8,9,8,8,7,7,6,7,7,6,5,4,2,1,1],
};
const DAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

const STORES = [
  { id:1, name:"Shoprite Kafubu Mall",   city:"Ndola", score:8,  tills:12, open:true  },
  { id:2, name:"Malak Supermarket",      city:"Ndola", score:3,  tills:4,  open:true  },
  { id:3, name:"Kafubu Shopping Mall",   city:"Ndola", score:6,  tills:8,  open:true  },
  { id:4, name:"Dola Hill Wholesale",    city:"Ndola", score:2,  tills:6,  open:false },
];

const PLANS = [
  { id:"starter",    name:"Starter",    price:"$99",  stores:"1 store",      color:"#10B981", feat:["Queue dashboard","WhatsApp templates","7-day forecast","Email support"] },
  { id:"growth",     name:"Growth",     price:"$249", stores:"Up to 5",      color:"#F59E0B", hot:true, feat:["Everything in Starter","AI insights","Auto alerts","Staff app","Priority support"] },
  { id:"enterprise", name:"Enterprise", price:"$599", stores:"Unlimited",    color:"#8B5CF6", feat:["Everything in Growth","White-label","API access","Account manager","Custom reports"] },
];

// ── ADVERTISING GRAPHIC (SVG) ─────────────────────────
function AdGraphic({ type }) {
  if (type === "hero") return (
    <svg viewBox="0 0 500 340" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width:"100%", height:"100%", borderRadius:20 }}>
      <rect width="500" height="340" fill="#1C1A17"/>
      {/* Background grid */}
      {[0,1,2,3,4,5,6,7,8,9].map(i=>(
        <line key={`h${i}`} x1="0" y1={34*i} x2="500" y2={34*i} stroke="#2A2620" strokeWidth=".5"/>
      ))}
      {[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14].map(i=>(
        <line key={`v${i}`} x1={36*i} y1="0" x2={36*i} y2="340" stroke="#2A2620" strokeWidth=".5"/>
      ))}
      {/* Amber glow orb */}
      <ellipse cx="380" cy="80" rx="120" ry="80" fill="#F59E0B" opacity=".08"/>
      <ellipse cx="120" cy="280" rx="100" ry="60" fill="#10B981" opacity=".06"/>
      {/* Store building */}
      <rect x="60" y="140" width="160" height="160" rx="4" fill="#2A2620"/>
      <rect x="72" y="152" width="136" height="100" rx="2" fill="#1C1A17"/>
      <rect x="88" y="168" width="36" height="40" rx="2" fill="#F59E0B" opacity=".3"/>
      <rect x="136" y="168" width="36" height="40" rx="2" fill="#F59E0B" opacity=".3"/>
      <rect x="100" y="220" width="80" height="80" rx="2" fill="#F59E0B" opacity=".15"/>
      <rect x="112" y="232" width="56" height="68" rx="1" fill="#2A2620"/>
      {/* Roof sign */}
      <rect x="52" y="120" width="176" height="28" rx="4" fill="#F59E0B"/>
      <text x="140" y="139" textAnchor="middle" fill="#0C0A08" fontSize="13" fontFamily="Plus Jakarta Sans" fontWeight="800">SHOPRITE</text>
      {/* Queue people */}
      {[0,1,2,3,4].map(i=>(
        <g key={i} transform={`translate(${300 + i*28}, 240)`}>
          <circle cx="0" cy="-20" r="10" fill={i===0?"#F59E0B":"#3A3630"}/>
          <rect x="-8" y="-10" width="16" height="24" rx="4" fill={i===0?"#F59E0B":"#3A3630"}/>
        </g>
      ))}
      {/* Queue line */}
      <line x1="280" y1="260" x2="470" y2="260" stroke="#F59E0B" strokeWidth="2" strokeDasharray="6 4" opacity=".4"/>
      {/* Alert box */}
      <rect x="280" y="100" width="190" height="110" rx="12" fill="#1E1B17" stroke="#F59E0B" strokeWidth="1.5"/>
      <rect x="294" y="115" width="60" height="8" rx="4" fill="#F59E0B"/>
      <text x="294" y="148" fill="#FAF7F2" fontSize="11" fontFamily="Plus Jakarta Sans">Queue Level</text>
      <text x="294" y="172" fill="#EF4444" fontSize="28" fontFamily="Fraunces" fontWeight="900">HIGH</text>
      <text x="294" y="192" fill="#8A8070" fontSize="10" fontFamily="Plus Jakarta Sans">Est. wait: 32 min</text>
      {/* Arrow + Phone */}
      <path d="M375 190 L395 190" stroke="#F59E0B" strokeWidth="2" markerEnd="url(#arr)"/>
      {/* InStore logo watermark */}
      <text x="250" y="330" textAnchor="middle" fill="#3A3630" fontSize="11" fontFamily="Plus Jakarta Sans" fontWeight="700">InStore AI · Ndola, Zambia</text>
    </svg>
  );

  if (type === "queue-card") return (
    <svg viewBox="0 0 400 220" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width:"100%", borderRadius:16 }}>
      <rect width="400" height="220" rx="16" fill="#1E1B17"/>
      <rect width="400" height="220" rx="16" fill="url(#qg)"/>
      <defs>
        <linearGradient id="qg" x1="0" y1="0" x2="400" y2="220" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#F59E0B" stopOpacity=".12"/>
          <stop offset="100%" stopColor="#10B981" stopOpacity=".06"/>
        </linearGradient>
      </defs>
      <text x="24" y="42" fill="#F59E0B" fontSize="11" fontFamily="JetBrains Mono" fontWeight="600" letterSpacing="2">LIVE QUEUE STATUS</text>
      <text x="24" y="88" fill="#FAF7F2" fontSize="52" fontFamily="Fraunces" fontWeight="900">8</text>
      <text x="80" y="74" fill="#8A8070" fontSize="20" fontFamily="Fraunces">/10</text>
      <rect x="24" y="100" width="80" height="24" rx="6" fill="#EF444422"/>
      <text x="64" y="117" textAnchor="middle" fill="#EF4444" fontSize="11" fontFamily="JetBrains Mono" fontWeight="600">VERY HIGH</text>
      <text x="24" y="158" fill="#8A8070" fontSize="13" fontFamily="Plus Jakarta Sans">Shoprite Kafubu Mall · Ndola</text>
      <text x="24" y="182" fill="#FAF7F2" fontSize="13" fontFamily="Plus Jakarta Sans" fontWeight="600">Est. wait time: <tspan fill="#F59E0B">32 minutes</tspan></text>
      <text x="24" y="205" fill="#3A3630" fontSize="10" fontFamily="JetBrains Mono">Powered by InStore AI</text>
      {/* Bars */}
      {[3,5,6,8,10,9,7,6,8,9,6,4].map((v,i)=>(
        <rect key={i} x={250+i*12} y={200-(v*12)} width="8" height={v*12} rx="2"
          fill={i===4?"#F59E0B":"#3A3630"} opacity={i===4?1:.7}/>
      ))}
      <text x="310" y="208" textAnchor="middle" fill="#8A8070" fontSize="9" fontFamily="JetBrains Mono">TODAY</text>
    </svg>
  );

  if (type === "whatsapp-mockup") return (
    <svg viewBox="0 0 360 280" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width:"100%", borderRadius:16 }}>
      <rect width="360" height="280" rx="16" fill="#1E1B17"/>
      {/* Phone frame */}
      <rect x="80" y="20" width="200" height="240" rx="20" fill="#141210" stroke="#2A2620" strokeWidth="1.5"/>
      {/* Status bar */}
      <rect x="80" y="20" width="200" height="36" rx="20" fill="#1C1A17"/>
      <rect x="80" y="44" width="200" height="8" fill="#1C1A17"/>
      <circle cx="180" cy="34" r="5" fill="#0C0A08"/>
      <text x="180" y="56" textAnchor="middle" fill="#FAF7F2" fontSize="10" fontFamily="Plus Jakarta Sans" fontWeight="600">WhatsApp</text>
      {/* Chat header */}
      <rect x="80" y="64" width="200" height="36" fill="#1E1B17"/>
      <circle cx="106" cy="82" r="12" fill="#10B981"/>
      <text x="106" y="87" textAnchor="middle" fill="white" fontSize="10" fontFamily="Plus Jakarta Sans" fontWeight="700">IS</text>
      <text x="124" y="79" fill="#FAF7F2" fontSize="10" fontFamily="Plus Jakarta Sans" fontWeight="700">InStore AI Alerts</text>
      <text x="124" y="93" fill="#10B981" fontSize="9" fontFamily="Plus Jakarta Sans">● Online</text>
      {/* Messages */}
      <rect x="92" y="110" width="150" height="52" rx="10" fill="#2A2620"/>
      <text x="102" y="128" fill="#FAF7F2" fontSize="9" fontFamily="Plus Jakarta Sans">🟢 Shoprite Kafubu is QUIET</text>
      <text x="102" y="143" fill="#8A8070" fontSize="9" fontFamily="Plus Jakarta Sans">Short queues right now.</text>
      <text x="102" y="157" fill="#10B981" fontSize="9" fontFamily="Plus Jakarta Sans" fontWeight="600">Perfect time to shop!</text>
      <text x="232" y="167" fill="#3A3630" fontSize="8" fontFamily="JetBrains Mono">9:41 ✓✓</text>

      <rect x="104" y="175" width="154" height="52" rx="10" fill="#F59E0B22" stroke="#F59E0B44" strokeWidth="1"/>
      <text x="114" y="193" fill="#FAF7F2" fontSize="9" fontFamily="Plus Jakarta Sans">🔴 Heads up! Very busy at</text>
      <text x="114" y="207" fill="#F59E0B" fontSize="9" fontFamily="Plus Jakarta Sans" fontWeight="600">Shoprite Kafubu Mall.</text>
      <text x="114" y="221" fill="#8A8070" fontSize="9" fontFamily="Plus Jakarta Sans">Visit after 8 PM instead.</text>
      <text x="242" y="231" fill="#3A3630" fontSize="8" fontFamily="JetBrains Mono">12:15 ✓✓</text>
      {/* Bottom bar */}
      <rect x="80" y="230" width="200" height="30" rx="16" fill="#1C1A17"/>
      <rect x="80" y="244" width="200" height="16" fill="#1C1A17"/>
      <rect x="92" y="238" width="140" height="16" rx="8" fill="#2A2620"/>
      <text x="162" y="250" textAnchor="middle" fill="#3A3630" fontSize="9" fontFamily="Plus Jakarta Sans">Message</text>
      <circle cx="248" cy="246" r="10" fill="#10B981"/>
    </svg>
  );

  if (type === "revenue") return (
    <svg viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width:"100%", borderRadius:16 }}>
      <rect width="400" height="200" rx="16" fill="#1E1B17"/>
      <defs>
        <linearGradient id="bargrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F59E0B"/>
          <stop offset="100%" stopColor="#D97706" stopOpacity=".3"/>
        </linearGradient>
      </defs>
      <text x="20" y="30" fill="#F59E0B" fontSize="10" fontFamily="JetBrains Mono" fontWeight="600" letterSpacing="2">MONTHLY REVENUE POTENTIAL</text>
      {/* Bars */}
      {[
        {label:"1 store", val:99,  max:600},
        {label:"3 stores",val:297, max:600},
        {label:"5 stores",val:495, max:600},
        {label:"10 stores",val:600,max:600},
      ].map(({label,val,max},i)=>{
        const bh = (val/max)*110;
        const x = 30 + i*90;
        return (
          <g key={i}>
            <rect x={x} y={160-bh} width="60" height={bh} rx="6" fill="url(#bargrad)" opacity={.4+i*.2}/>
            <text x={x+30} y={155-bh} textAnchor="middle" fill="#F59E0B" fontSize="11" fontFamily="JetBrains Mono" fontWeight="600">${val=== 600?"600+":val}</text>
            <text x={x+30} y="178" textAnchor="middle" fill="#8A8070" fontSize="9" fontFamily="Plus Jakarta Sans">{label}</text>
          </g>
        );
      })}
      <text x="200" y="198" textAnchor="middle" fill="#3A3630" fontSize="9" fontFamily="JetBrains Mono">InStore AI · Starter Plan pricing</text>
    </svg>
  );

  return null;
}

// ── AI INSIGHT ────────────────────────────────────────
function AIInsight({ store, hour, day, score }) {
  const [text, setText] = useState("");
  const [status, setStatus] = useState("idle");
  async function go() {
    setStatus("loading"); setText("");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514", max_tokens:1000,
          messages:[{ role:"user", content:`You are InStore AI for ${store} in Ndola, Zambia.
Day: ${day}, Hour: ${hour}:00, Queue score: ${score}/10.
Write 3 simple, friendly sentences for a store manager:
1. What is happening right now and why
2. One quick action they should take right now
3. One tip to help customers

Keep it simple and warm. No bullet points.` }],
        }),
      });
      const d = await res.json();
      setText(d.content?.[0]?.text ?? "Could not get insight.");
      setStatus("done");
    } catch { setText("No internet connection. Try again."); setStatus("error"); }
  }
  return (
    <div style={{ marginTop:18 }}>
      {status==="idle" && (
        <button onClick={go} style={{ background:"linear-gradient(135deg,#F59E0B,#D97706)", border:"none", borderRadius:10, padding:"11px 26px", color:"#0C0A08", fontWeight:800, fontSize:13, display:"flex", alignItems:"center", gap:8 }}>
          ✦ Ask AI What To Do
        </button>
      )}
      {status==="loading" && (
        <div style={{ color:"#F59E0B", fontSize:13, display:"flex", gap:8, alignItems:"center" }}>
          <span style={{ animation:"spin 1s linear infinite", display:"inline-block" }}>◌</span> Thinking…
        </div>
      )}
      {(status==="done"||status==="error") && (
        <div style={{ background:"#1a1200", border:"1px solid #F59E0B44", borderRadius:14, padding:"16px 18px", position:"relative" }}>
          <div style={{ color:"#F59E0B", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:2, marginBottom:10 }}>✦ AI RECOMMENDATION</div>
          <div style={{ color:"#FAF7F2", fontSize:14, lineHeight:1.8 }}>{text}</div>
          <button onClick={()=>setStatus("idle")} style={{ position:"absolute", top:12, right:14, background:"none", border:"none", color:"#F59E0B", fontSize:20 }}>×</button>
        </div>
      )}
    </div>
  );
}

// ── LANDING PAGE ──────────────────────────────────────
function Landing({ onLogin, onSignup }) {
  const [hovPlan, setHovPlan] = useState(null);

  return (
    <div style={{ background:"var(--bg)", minHeight:"100vh", color:"var(--text)" }}>

      {/* NAV */}
      <nav style={{ position:"sticky", top:0, zIndex:100, background:"#0C0A08ee", backdropFilter:"blur(16px)", borderBottom:"1px solid #2A2620", padding:"14px 24px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <Logo size={34} />
        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
          <button onClick={onLogin} style={{ background:"none", border:"1px solid #2A2620", borderRadius:8, color:"#8A8070", padding:"8px 18px", fontWeight:600, fontSize:13 }}>Log In</button>
          <button onClick={onSignup} style={{ background:"linear-gradient(135deg,#F59E0B,#D97706)", border:"none", borderRadius:8, color:"#0C0A08", padding:"8px 20px", fontWeight:800, fontSize:13 }}>Try Free →</button>
        </div>
      </nav>

      {/* HERO */}
      <div style={{ maxWidth:1000, margin:"0 auto", padding:"70px 24px 40px" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:48, alignItems:"center" }}>
          <div>
            <div className="fu1" style={{ display:"inline-flex", alignItems:"center", gap:8, background:"#1a1200", border:"1px solid #F59E0B44", borderRadius:50, padding:"6px 16px", marginBottom:24 }}>
              <div className="pulse" style={{ width:6, height:6, borderRadius:"50%", background:"#F59E0B" }} />
              <span style={{ color:"#F59E0B", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1 }}>LIVE IN NDOLA, ZAMBIA 🇿🇲</span>
            </div>

            <h1 className="fu2" style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:"clamp(32px,5vw,58px)", lineHeight:1.08, letterSpacing:"-1.5px", marginBottom:20 }}>
              Know Your Queue.<br/>
              <em style={{ color:"#F59E0B", fontStyle:"italic" }}>Grow Your Store.</em>
            </h1>

            <p className="fu3" style={{ color:"#8A8070", fontSize:17, lineHeight:1.75, marginBottom:32, maxWidth:440 }}>
              InStore AI watches your checkout queues, predicts busy times, and sends WhatsApp alerts to customers — so your store runs smoother every day.
            </p>

            <div className="fu4" style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
              <button onClick={onSignup} className="glow-amber" style={{ background:"linear-gradient(135deg,#F59E0B,#D97706)", border:"none", borderRadius:12, color:"#0C0A08", padding:"16px 32px", fontWeight:800, fontSize:16 }}>
                Start Free — 14 Days →
              </button>
              <button onClick={onLogin} style={{ background:"#1C1A17", border:"1px solid #2A2620", borderRadius:12, color:"#FAF7F2", padding:"16px 28px", fontWeight:700, fontSize:15 }}>
                See Demo
              </button>
            </div>

            <div className="fu5" style={{ display:"flex", gap:24, marginTop:32, flexWrap:"wrap" }}>
              {[["✓","No credit card needed"],["✓","Works on any phone"],["✓","Setup in 2 minutes"]].map(([icon,txt])=>(
                <div key={txt} style={{ display:"flex", gap:7, alignItems:"center" }}>
                  <span style={{ color:"#10B981", fontWeight:800 }}>{icon}</span>
                  <span style={{ color:"#8A8070", fontSize:13 }}>{txt}</span>
                </div>
              ))}
            </div>
          </div>

          {/* HERO GRAPHIC */}
          <div className="fu2 float" style={{ borderRadius:20, overflow:"hidden", border:"1px solid #2A2620", aspectRatio:"500/340" }}>
            <AdGraphic type="hero" />
          </div>
        </div>
      </div>

      {/* TICKER */}
      <div style={{ background:"#1a1200", borderTop:"1px solid #2A2620", borderBottom:"1px solid #2A2620", padding:"10px 0", overflow:"hidden" }}>
        <div style={{ animation:"ticker 20s linear infinite", display:"flex", width:"max-content", whiteSpace:"nowrap" }}>
          {[
            "🟢 Malak Supermarket — QUIET — Best time to shop now",
            "🔴 Shoprite Kafubu — HIGH — 8 people per till",
            "💬 WhatsApp alert sent to 412 customers",
            "📊 Saturday peak: 9 AM – 11 AM · Plan ahead",
            "✅ Revenue saved this week: $1,200",
            "🟡 Kafubu Mall — MODERATE — Est. 16 min wait",
          ].concat(["🟢 Malak Supermarket — QUIET — Best time to shop now","🔴 Shoprite Kafubu — HIGH — 8 people per till","💬 WhatsApp alert sent to 412 customers"]).join("   ·   ")}
          <span style={{ color:"#F59E0B", fontSize:12, fontFamily:"'JetBrains Mono',monospace", letterSpacing:.5, paddingRight:80 }}>&nbsp;</span>
        </div>
      </div>

      {/* HOW IT WORKS */}
      <div style={{ maxWidth:1000, margin:"60px auto 0", padding:"0 24px" }}>
        <div style={{ textAlign:"center", marginBottom:48 }}>
          <div style={{ color:"#F59E0B", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:2, marginBottom:10 }}>HOW IT WORKS</div>
          <h2 style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:38, letterSpacing:"-1px" }}>Simple for any store owner</h2>
          <p style={{ color:"#8A8070", marginTop:12, fontSize:16 }}>No tech skills needed. If you can send a WhatsApp, you can use InStore AI.</p>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:20 }}>
          {[
            { n:"01", icon:"📍", title:"Add Your Store", desc:"Enter your store name, location, and opening hours. Done in under 2 minutes." },
            { n:"02", icon:"👤", title:"Staff Log Queue", desc:"Every 30 minutes, staff tap a number 1–10 to show how busy the checkout is." },
            { n:"03", icon:"🤖", title:"AI Reads the Data", desc:"InStore AI predicts busy times, gives your manager advice, and plans your staffing." },
            { n:"04", icon:"💬", title:"Alert Your Customers", desc:"Automatic WhatsApp messages tell customers when it's quiet — they come in, you sell more." },
          ].map(({ n, icon, title, desc }) => (
            <div key={n} style={{ background:"#1C1A17", border:"1px solid #2A2620", borderRadius:16, padding:"26px 22px", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:14, right:18, fontFamily:"'JetBrains Mono',monospace", fontSize:36, color:"#2A2620", fontWeight:700 }}>{n}</div>
              <div style={{ fontSize:32, marginBottom:16 }}>{icon}</div>
              <div style={{ fontFamily:"'Fraunces',serif", fontWeight:700, fontSize:19, marginBottom:10 }}>{title}</div>
              <div style={{ color:"#8A8070", fontSize:14, lineHeight:1.7 }}>{desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* AD GRAPHICS SECTION */}
      <div style={{ maxWidth:1000, margin:"60px auto 0", padding:"0 24px" }}>
        <div style={{ textAlign:"center", marginBottom:40 }}>
          <div style={{ color:"#F59E0B", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:2, marginBottom:10 }}>WHAT YOU GET</div>
          <h2 style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:38, letterSpacing:"-1px" }}>Built for Zambian stores</h2>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))", gap:20 }}>
          <div>
            <div style={{ marginBottom:12, color:"#FAF7F2", fontWeight:700, fontSize:15 }}>Live Queue Card</div>
            <AdGraphic type="queue-card" />
            <div style={{ color:"#8A8070", fontSize:13, marginTop:10, lineHeight:1.6 }}>Shows the queue score, wait time, and today's trend — visible on any screen at the entrance.</div>
          </div>
          <div>
            <div style={{ marginBottom:12, color:"#FAF7F2", fontWeight:700, fontSize:15 }}>WhatsApp Customer Alerts</div>
            <AdGraphic type="whatsapp-mockup" />
            <div style={{ color:"#8A8070", fontSize:13, marginTop:10, lineHeight:1.6 }}>Customers get a WhatsApp message when queues are short. They come in, you earn more.</div>
          </div>
          <div>
            <div style={{ marginBottom:12, color:"#FAF7F2", fontWeight:700, fontSize:15 }}>Your Revenue Potential</div>
            <AdGraphic type="revenue" />
            <div style={{ color:"#8A8070", fontSize:13, marginTop:10, lineHeight:1.6 }}>One store at $99/mo. Five stores pays you $495/mo. Ten stores = $600+/mo steady income.</div>
          </div>
        </div>
      </div>

      {/* PRICING */}
      <div style={{ maxWidth:1000, margin:"60px auto 0", padding:"0 24px 80px" }}>
        <div style={{ textAlign:"center", marginBottom:48 }}>
          <div style={{ color:"#F59E0B", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:2, marginBottom:10 }}>PRICING</div>
          <h2 style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:38, letterSpacing:"-1px" }}>One flat monthly price</h2>
          <p style={{ color:"#8A8070", marginTop:10, fontSize:16 }}>Cancel any time. No hidden fees. Start free for 14 days.</p>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))", gap:16 }}>
          {PLANS.map(p=>(
            <div key={p.id}
              onMouseEnter={()=>setHovPlan(p.id)} onMouseLeave={()=>setHovPlan(null)}
              style={{ background: p.hot?"#1a1200":"#1C1A17", border:`1.5px solid ${hovPlan===p.id||p.hot?p.color+"66":"#2A2620"}`, borderRadius:20, padding:"28px 24px", position:"relative", transition:"all .25s", transform:hovPlan===p.id?"translateY(-5px)":"none" }}>
              {p.hot && <div style={{ position:"absolute", top:-13, left:"50%", transform:"translateX(-50%)", background:p.color, color:"#0C0A08", fontSize:10, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, letterSpacing:1, borderRadius:50, padding:"4px 16px", whiteSpace:"nowrap" }}>MOST POPULAR</div>}
              <div style={{ color:p.color, fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:2, marginBottom:8 }}>{p.name.toUpperCase()}</div>
              <div style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:44, lineHeight:1 }}>{p.price}<span style={{ fontSize:15, color:"#8A8070", fontFamily:"'Plus Jakarta Sans',sans-serif", fontWeight:400 }}>/mo</span></div>
              <div style={{ color:"#8A8070", fontSize:13, margin:"6px 0 22px", background:`${p.color}11`, borderRadius:6, padding:"4px 10px", display:"inline-block" }}>{p.stores}</div>
              <div style={{ marginBottom:24 }}>
                {p.feat.map((f,i)=>(
                  <div key={i} style={{ display:"flex", gap:10, marginBottom:10, alignItems:"flex-start" }}>
                    <span style={{ color:p.color }}>✓</span>
                    <span style={{ color:"#8A8070", fontSize:13, lineHeight:1.5 }}>{f}</span>
                  </div>
                ))}
              </div>
              <button onClick={onSignup} style={{ width:"100%", padding:"14px 0", background:p.hot?`linear-gradient(135deg,${p.color},${p.color}bb)`:"none", border:p.hot?"none":`1px solid ${p.color}66`, borderRadius:10, color:p.hot?"#0C0A08":p.color, fontWeight:800, fontSize:13, letterSpacing:.5 }}>
                {p.hot?"Get Started Free":"Choose Plan"}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* FOOTER */}
      <div style={{ borderTop:"1px solid #2A2620", padding:"32px 24px", textAlign:"center" }}>
        <Logo size={28} />
        <div style={{ color:"#3A3630", fontSize:12, marginTop:16, fontFamily:"'JetBrains Mono',monospace" }}>
          © 2025 InStore AI · Ndola, Zambia · All Rights Reserved · You own this.
        </div>
      </div>
    </div>
  );
}

// ── AUTH ──────────────────────────────────────────────
function Auth({ mode, onDone, onToggle }) {
  const [email,setEmail]=useState("");
  const [pass,setPass]=useState("");
  const [store,setStore]=useState("");
  const [loading,setLoading]=useState(false);
  const [err,setErr]=useState("");

  function submit() {
    if (!email||!pass) { setErr("Please fill in all fields."); return; }
    if (mode==="signup"&&!store) { setErr("Enter your store or business name."); return; }
    setErr(""); setLoading(true);
    setTimeout(()=>{ setLoading(false); onDone({ email, store: store||"My Store", plan:"starter" }); }, 1200);
  }

  return (
    <div style={{ minHeight:"100vh", background:"#0C0A08", display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
      <div style={{ width:"100%", maxWidth:420, background:"#1C1A17", border:"1px solid #2A2620", borderRadius:20, padding:"38px 32px", animation:"fadeIn .4s ease" }}>
        <div style={{ marginBottom:28 }}><Logo size={32} /></div>
        <h2 style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:28, marginBottom:6 }}>
          {mode==="login"?"Welcome back 👋":"Create your account"}
        </h2>
        <p style={{ color:"#8A8070", fontSize:14, marginBottom:28, lineHeight:1.6 }}>
          {mode==="login"?"Log into your InStore AI dashboard.":"14-day free trial. No credit card needed."}
        </p>

        {mode==="signup"&&(
          <div style={{ marginBottom:14 }}>
            <label style={{ color:"#8A8070", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1 }}>YOUR STORE / BUSINESS NAME</label>
            <input value={store} onChange={e=>setStore(e.target.value)} placeholder="e.g. Shoprite Kafubu Mall"
              style={{ width:"100%", marginTop:7, background:"#141210", border:"1px solid #2A2620", borderRadius:9, color:"#FAF7F2", padding:"11px 14px", fontSize:14 }} />
          </div>
        )}
        <div style={{ marginBottom:14 }}>
          <label style={{ color:"#8A8070", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1 }}>EMAIL ADDRESS</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@store.com" type="email"
            style={{ width:"100%", marginTop:7, background:"#141210", border:"1px solid #2A2620", borderRadius:9, color:"#FAF7F2", padding:"11px 14px", fontSize:14 }} />
        </div>
        <div style={{ marginBottom:22 }}>
          <label style={{ color:"#8A8070", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1 }}>PASSWORD</label>
          <input value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" type="password"
            style={{ width:"100%", marginTop:7, background:"#141210", border:"1px solid #2A2620", borderRadius:9, color:"#FAF7F2", padding:"11px 14px", fontSize:14 }} />
        </div>
        {err&&<div style={{ color:"#EF4444", fontSize:13, marginBottom:14, fontFamily:"'JetBrains Mono',monospace" }}>{err}</div>}
        <button onClick={submit} style={{ width:"100%", padding:"15px 0", background:"linear-gradient(135deg,#F59E0B,#D97706)", border:"none", borderRadius:11, color:"#0C0A08", fontWeight:800, fontSize:15, opacity:loading?.7:1 }}>
          {loading?"Loading…":mode==="login"?"Log In →":"Create Free Account →"}
        </button>
        <div style={{ textAlign:"center", marginTop:18, color:"#8A8070", fontSize:14 }}>
          {mode==="login"?"No account? ":"Have an account? "}
          <span onClick={onToggle} style={{ color:"#F59E0B", cursor:"pointer", fontWeight:700 }}>
            {mode==="login"?"Sign up free":"Log in"}
          </span>
        </div>
      </div>
    </div>
  );
}

// ── DASHBOARD ─────────────────────────────────────────
function Dashboard({ user, onLogout }) {
  const now = new Date();
  const [tab,setTab]=useState("overview");
  const [store,setStore]=useState(STORES[0]);
  const [day,setDay]=useState(DAYS[now.getDay()]);
  const [hour,setHour]=useState(now.getHours());
  const [manual,setManual]=useState(null);
  const [log,setLog]=useState([]);
  const [copied,setCopied]=useState(null);
  const [modal,setModal]=useState(false);

  const pred = PEAK[day]?.[hour]??5;
  const score = manual!==null?manual:pred;
  const lv = ql(score);
  const best = (PEAK[day]||[]).map((v,i)=>({h:i,v})).filter(x=>x.v<=3&&x.h>=8);

  function logIt(val) {
    setManual(val);
    const t=new Date();
    setLog(p=>[{time:`${String(t.getHours()).padStart(2,"0")}:${String(t.getMinutes()).padStart(2,"0")}`,store:store.name,score:val,level:ql(val).label},...p].slice(0,40));
  }

  const WA=[
    {tag:"QUIET NOW",  color:"#10B981", msg:`🟢 Good news! ${store.name} is very quiet right now. Short queues, fast checkout. Come shop! – InStore AI`},
    {tag:"VERY BUSY",  color:"#EF4444", msg:`🔴 ${store.name} is very busy right now. Come back after 8 PM for a quicker experience. – InStore AI`},
    {tag:"BEST TIMES", color:"#F59E0B", msg:`📅 Best times at ${store.name} today: 8–10 AM or after 7 PM. Avoid 12–2 PM rush. – InStore AI`},
    {tag:"STAFF ALERT",color:"#8B5CF6", msg:`⚠️ MANAGER: Queue is HIGH at ${store.name}. Please open more tills immediately. – InStore AI`},
  ];

  const TABS=[{id:"overview",icon:"🏠",l:"Overview"},{id:"queue",icon:"📊",l:"Queue"},{id:"forecast",icon:"📅",l:"Forecast"},{id:"whatsapp",icon:"💬",l:"WhatsApp"},{id:"log",icon:"📋",l:"Log"},{id:"billing",icon:"💳",l:"Billing"}];

  return (
    <div style={{ minHeight:"100vh", background:"#0C0A08", color:"#FAF7F2" }}>
      <style>{`
        .s-card{background:#1C1A17;border:1px solid #2A2620;border-radius:16px;padding:20px}
        .s-tab{background:none;border:none;padding:12px 14px;font-family:'Plus Jakarta Sans',sans-serif;font-size:12px;font-weight:700;border-bottom:2px solid transparent;transition:all .2s;white-space:nowrap;display:flex;align-items:center;gap:6px}
        .s-tab.on{color:#F59E0B;border-bottom-color:#F59E0B}
        .s-tab.off{color:#3A3630}
        .s-tab.off:hover{color:#8A8070}
        .n-btn{width:40px;height:40px;border-radius:9px;border:2px solid #2A2620;background:#1C1A17;font-weight:800;font-size:14px;transition:all .15s;color:#3A3630}
      `}</style>

      {/* NAV */}
      <div style={{ background:"#0C0A08", borderBottom:"1px solid #2A2620", padding:"13px 20px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, zIndex:50 }}>
        <Logo size={30} />
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ background:"#1a1200", border:"1px solid #F59E0B33", borderRadius:6, padding:"3px 12px", color:"#F59E0B", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1 }}>STARTER</div>
          <div style={{ color:"#3A3630", fontSize:12 }}>{user.email}</div>
          <button onClick={onLogout} style={{ background:"none", border:"1px solid #2A2620", borderRadius:7, color:"#8A8070", padding:"6px 12px", fontSize:12, fontWeight:600 }}>Logout</button>
        </div>
      </div>

      {/* STORE PILLS */}
      <div style={{ background:"#141210", borderBottom:"1px solid #2A2620", padding:"10px 18px", display:"flex", gap:8, overflowX:"auto" }}>
        {STORES.map(s=>(
          <button key={s.id} onClick={()=>{setStore(s);setManual(null);}} style={{ padding:"7px 16px", borderRadius:8, border:`1px solid ${store.id===s.id?"#F59E0B66":"#2A2620"}`, background:store.id===s.id?"#1a1200":"#1C1A17", color:store.id===s.id?"#F59E0B":"#8A8070", fontSize:12, fontWeight:600, whiteSpace:"nowrap", display:"flex", alignItems:"center", gap:7 }}>
            <span className="pulse" style={{ width:6, height:6, borderRadius:"50%", background:s.open?ql(s.score).color:"#3A3630", display:"inline-block" }} />
            {s.name}
          </button>
        ))}
        <button onClick={()=>setModal(true)} style={{ padding:"7px 16px", borderRadius:8, border:"1px dashed #F59E0B33", background:"none", color:"#F59E0B66", fontSize:12, fontWeight:600, whiteSpace:"nowrap" }}>+ Add Store</button>
      </div>

      {/* TABS */}
      <div style={{ background:"#0C0A08", borderBottom:"1px solid #2A2620", display:"flex", overflowX:"auto" }}>
        {TABS.map(t=>(
          <button key={t.id} className={`s-tab ${tab===t.id?"on":"off"}`} onClick={()=>setTab(t.id)}>
            <span>{t.icon}</span>{t.l}
          </button>
        ))}
      </div>

      <div style={{ maxWidth:800, margin:"0 auto", padding:"20px 14px 60px" }}>

        {/* OVERVIEW */}
        {tab==="overview"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .4s ease both" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:8 }}>
              <div>
                <h2 style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:24 }}>{store.name}</h2>
                <div style={{ color:"#8A8070", fontSize:13, marginTop:2 }}>{store.city}, Zambia · {store.tills} tills</div>
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:7, background: store.open?"#061a10":"#1C1A17", borderRadius:20, padding:"6px 14px", border:`1px solid ${store.open?"#10B98133":"#2A2620"}` }}>
                <div className="pulse" style={{ width:7, height:7, borderRadius:"50%", background:store.open?"#10B981":"#3A3630" }} />
                <span style={{ color:store.open?"#10B981":"#8A8070", fontSize:12, fontWeight:700 }}>{store.open?"OPEN":"CLOSED"}</span>
              </div>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))", gap:12 }}>
              {[
                {l:"Queue Score",v:`${score}/10`,c:lv.color},
                {l:"Est. Wait",v:`${score*4}min`,c:"#FAF7F2"},
                {l:"Tills Needed",v:`${Math.max(1,Math.round(store.tills*(score/10)))}/${store.tills}`,c:"#F59E0B"},
                {l:"Status",v:lv.label,c:lv.color},
              ].map(({l,v,c})=>(
                <div key={l} className="s-card">
                  <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:8 }}>{l.toUpperCase()}</div>
                  <div style={{ color:c, fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:26 }}>{v}</div>
                </div>
              ))}
            </div>

            <div className="s-card">
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:14 }}>ALL STORES — LIVE</div>
              {STORES.map(s=>{
                const slv=ql(s.score);
                return (
                  <div key={s.id} onClick={()=>setStore(s)} style={{ display:"flex", alignItems:"center", gap:12, padding:"11px 0", borderBottom:"1px solid #2A2620", cursor:"pointer" }}>
                    <div style={{ width:8, height:8, borderRadius:"50%", background:s.open?slv.color:"#3A3630", flexShrink:0 }} />
                    <div style={{ flex:1, fontSize:14, fontWeight:600, color:store.id===s.id?"#F59E0B":"#FAF7F2" }}>{s.name}</div>
                    <div style={{ background:`${slv.color}22`, color:slv.color, borderRadius:6, padding:"3px 12px", fontSize:11, fontFamily:"'JetBrains Mono',monospace" }}>
                      {s.open?slv.label:"CLOSED"}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* QUEUE */}
        {tab==="queue"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .4s ease both" }}>
            <div className="s-card" style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
              {[["DAY",day,DAYS,v=>{setDay(v);setManual(null);}],["HOUR",hour,Array.from({length:24},(_,i)=>i),v=>{setHour(+v);setManual(null);}]].map(([label,val,opts,fn])=>(
                <div key={label} style={{ flex:1, minWidth:130 }}>
                  <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:7 }}>{label}</div>
                  <select value={val} onChange={e=>fn(e.target.value)} style={{ width:"100%", background:"#141210", border:"1px solid #2A2620", borderRadius:8, color:"#FAF7F2", padding:"9px 12px", fontSize:13 }}>
                    {opts.map(o=><option key={o} value={o}>{label==="HOUR"?String(o).padStart(2,"0")+":00":o}</option>)}
                  </select>
                </div>
              ))}
            </div>

            <div className="s-card" style={{ border:`1.5px solid ${lv.color}55`, background:lv.bg }}>
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:14 }}>LIVE QUEUE · {store.name.toUpperCase()}</div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", flexWrap:"wrap", gap:12 }}>
                <div>
                  <div style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:72, color:lv.color, lineHeight:1 }}>
                    {score}<span style={{ fontSize:28, color:"#2A2620" }}>/10</span>
                  </div>
                  <div style={{ marginTop:10, display:"inline-block", background:`${lv.color}22`, color:lv.color, borderRadius:8, padding:"6px 16px", fontSize:13, fontWeight:800, letterSpacing:1 }}>
                    {lv.label.toUpperCase()}
                  </div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ color:"#3A3630", fontSize:11, fontFamily:"'JetBrains Mono',monospace" }}>ESTIMATED WAIT</div>
                  <div style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:36, color:"#FAF7F2", marginTop:4 }}>{score*4} min</div>
                  <div style={{ color:"#3A3630", fontSize:10, marginTop:4 }}>{manual!==null?"● Staff logged":"◎ AI predicted"}</div>
                </div>
              </div>
              <div style={{ marginTop:18, background:"#0C0A08", borderRadius:8, height:8, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${score*10}%`, background:`linear-gradient(90deg,${lv.color}55,${lv.color})`, borderRadius:8, transition:"width .6s ease" }} />
              </div>
              <AIInsight store={store.name} hour={hour} day={day} score={score} />
            </div>

            <div className="s-card">
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:14 }}>STAFF — TAP TO LOG QUEUE (every 30 min)</div>
              <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
                {[1,2,3,4,5,6,7,8,9,10].map(v=>{
                  const lv2=ql(v);const a=manual===v;
                  return <button key={v} className="n-btn" onClick={()=>logIt(v)} style={{ borderColor:a?lv2.color:"#2A2620", background:a?`${lv2.color}22`:"#1C1A17", color:a?lv2.color:"#3A3630" }}>{v}</button>;
                })}
              </div>
              <div style={{ color:"#3A3630", fontSize:12, marginTop:10 }}>1 = almost empty · 10 = completely full</div>
            </div>

            <div className="s-card">
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:12 }}>BEST TIMES TO SHOP TODAY</div>
              <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                {best.length>0?best.map(({h})=>(
                  <div key={h} style={{ background:"#061a10", border:"1px solid #10B98133", borderRadius:9, padding:"8px 18px", color:"#10B981", fontFamily:"'JetBrains Mono',monospace", fontWeight:600, fontSize:15 }}>
                    {String(h).padStart(2,"0")}:00
                  </div>
                )):<div style={{ color:"#3A3630", fontSize:14 }}>No quiet windows found — try early morning.</div>}
              </div>
            </div>
          </div>
        )}

        {/* FORECAST */}
        {tab==="forecast"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .4s ease both" }}>
            <div className="s-card">
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16, flexWrap:"wrap", gap:10 }}>
                <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5 }}>24-HOUR FORECAST</div>
                <select value={day} onChange={e=>setDay(e.target.value)} style={{ background:"#141210", border:"1px solid #2A2620", borderRadius:7, color:"#FAF7F2", padding:"6px 12px", fontSize:12, fontFamily:"'JetBrains Mono',monospace" }}>
                  {DAYS.map(d=><option key={d}>{d}</option>)}
                </select>
              </div>
              <div style={{ display:"flex", alignItems:"flex-end", gap:3, height:140, overflowX:"auto", paddingBottom:6 }}>
                {(PEAK[day]||[]).map((s,h)=>{
                  const lv2=ql(s); const bh=Math.max(4,(s/10)*125); const isNow=h===hour;
                  return (
                    <div key={h} style={{ display:"flex", flexDirection:"column", alignItems:"center", flex:1, minWidth:20 }}>
                      <div style={{ width:"100%", height:bh, background:isNow?lv2.color:`${lv2.color}44`, borderRadius:"3px 3px 0 0", border:isNow?`1.5px solid ${lv2.color}`:"none", position:"relative", transition:"height .4s" }}>
                        {isNow&&<div style={{ position:"absolute", top:-18, left:"50%", transform:"translateX(-50%)", color:lv2.color, fontSize:8, fontFamily:"'JetBrains Mono',monospace", whiteSpace:"nowrap" }}>NOW</div>}
                      </div>
                      <div style={{ color:"#2A2620", fontSize:8, fontFamily:"'JetBrains Mono',monospace", marginTop:4 }}>{String(h).padStart(2,"0")}</div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="s-card">
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:14 }}>WEEKLY OVERVIEW</div>
              {DAYS.map(d=>{
                const pk=Math.max(...(PEAK[d]||[]));const ph=(PEAK[d]||[]).indexOf(pk);const lv2=ql(pk);
                return (
                  <div key={d} style={{ display:"flex", alignItems:"center", gap:12, marginBottom:12 }}>
                    <div style={{ width:88, color:"#8A8070", fontSize:12, fontFamily:"'JetBrains Mono',monospace" }}>{d.slice(0,3).toUpperCase()}</div>
                    <div style={{ flex:1, background:"#141210", borderRadius:5, height:7, overflow:"hidden" }}>
                      <div style={{ width:`${pk*10}%`, height:"100%", background:`linear-gradient(90deg,${lv2.color}44,${lv2.color})`, borderRadius:5 }} />
                    </div>
                    <div style={{ color:lv2.color, fontSize:11, fontFamily:"'JetBrains Mono',monospace", width:64, textAlign:"right" }}>Peak {String(ph).padStart(2,"0")}:00</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* WHATSAPP */}
        {tab==="whatsapp"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:14, animation:"fadeUp .4s ease both" }}>
            <div className="s-card">
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:6 }}>WHATSAPP MESSAGES · {store.name.toUpperCase()}</div>
              <div style={{ color:"#8A8070", fontSize:14, marginBottom:20, lineHeight:1.6 }}>Tap any message to copy it. Then paste into WhatsApp Business or Twilio to send to your customers.</div>
              {WA.map((m,i)=>(
                <div key={i} onClick={()=>{navigator.clipboard.writeText(m.msg);setCopied(i);setTimeout(()=>setCopied(null),2200);}}
                  style={{ background:copied===i?"#061a10":"#1C1A17", border:`1px solid ${copied===i?"#10B981":m.color+"33"}`, borderRadius:14, padding:"16px 18px", marginBottom:12, cursor:"pointer", transition:"all .2s" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
                    <div style={{ background:`${m.color}22`, color:m.color, borderRadius:6, padding:"4px 12px", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1 }}>{m.tag}</div>
                    <div style={{ color:copied===i?"#10B981":"#3A3630", fontSize:11, fontFamily:"'JetBrains Mono',monospace" }}>{copied===i?"✓ COPIED":"TAP TO COPY"}</div>
                  </div>
                  <div style={{ color:"#8A8070", fontSize:14, lineHeight:1.7 }}>{m.msg}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LOG */}
        {tab==="log"&&(
          <div className="s-card" style={{ animation:"fadeUp .4s ease both" }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:14 }}>
              <div style={{ color:"#3A3630", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5 }}>QUEUE LOG HISTORY</div>
              {log.length>0&&<button onClick={()=>setLog([])} style={{ background:"none", border:"none", color:"#3A3630", fontSize:12 }}>Clear</button>}
            </div>
            {log.length===0?(
              <div style={{ color:"#3A3630", fontSize:14, textAlign:"center", padding:"40px 0", lineHeight:1.8 }}>No entries yet.<br/>Go to the Queue tab and tap a number to log.</div>
            ):log.map((e,i)=>{
              const lv2=ql(e.score);
              return (
                <div key={i} style={{ display:"flex", alignItems:"center", gap:12, padding:"10px 0", borderBottom:"1px solid #1C1A17" }}>
                  <div style={{ color:"#3A3630", fontFamily:"'JetBrains Mono',monospace", fontSize:12, width:42 }}>{e.time}</div>
                  <div style={{ flex:1, fontSize:13, color:"#8A8070" }}>{e.store}</div>
                  <div style={{ color:lv2.color, fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:22 }}>{e.score}</div>
                  <div style={{ background:`${lv2.color}22`, color:lv2.color, borderRadius:6, padding:"3px 10px", fontSize:11, fontFamily:"'JetBrains Mono',monospace" }}>{e.level}</div>
                </div>
              );
            })}
          </div>
        )}

        {/* BILLING */}
        {tab==="billing"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .4s ease both" }}>
            <div className="s-card" style={{ border:"1px solid #F59E0B33", background:"#1a1200" }}>
              <div style={{ color:"#F59E0B", fontSize:10, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:10 }}>YOUR PLAN</div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:12 }}>
                <div>
                  <div style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:30 }}>Starter Plan</div>
                  <div style={{ color:"#8A8070", fontSize:13, marginTop:4 }}>$99/month · 1 store · 14-day trial active</div>
                </div>
                <button onClick={()=>setModal(true)} style={{ background:"linear-gradient(135deg,#F59E0B,#D97706)", border:"none", borderRadius:9, padding:"11px 24px", color:"#0C0A08", fontWeight:800, fontSize:13 }}>Upgrade Plan</button>
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:14 }}>
              {PLANS.map(p=>(
                <div key={p.id} style={{ background:"#1C1A17", border:`1px solid ${p.color}33`, borderRadius:16, padding:"22px 20px" }}>
                  <div style={{ color:p.color, fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:2, marginBottom:8 }}>{p.name.toUpperCase()}</div>
                  <div style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:36 }}>{p.price}<span style={{ fontSize:14, color:"#8A8070", fontFamily:"'Plus Jakarta Sans',sans-serif" }}>/mo</span></div>
                  <div style={{ color:"#8A8070", fontSize:12, margin:"4px 0 16px", background:`${p.color}11`, borderRadius:5, padding:"3px 10px", display:"inline-block" }}>{p.stores}</div>
                  {p.feat.slice(0,3).map((f,i)=>(
                    <div key={i} style={{ display:"flex", gap:8, marginBottom:8 }}>
                      <span style={{ color:p.color }}>✓</span>
                      <span style={{ color:"#8A8070", fontSize:12 }}>{f}</span>
                    </div>
                  ))}
                  <button onClick={()=>setModal(true)} style={{ width:"100%", marginTop:14, padding:"10px 0", background:"none", border:`1px solid ${p.color}55`, borderRadius:8, color:p.color, fontWeight:700, fontSize:12 }}>
                    {p.id==="starter"?"Current Plan":"Upgrade →"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* MODAL */}
      {modal&&(
        <div onClick={()=>setModal(false)} style={{ position:"fixed", inset:0, background:"#000000cc", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, padding:20 }}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#1C1A17", border:"1px solid #2A2620", borderRadius:20, padding:"32px 28px", maxWidth:380, width:"100%", animation:"fadeUp .3s ease" }}>
            <Logo size={28} />
            <h3 style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:24, margin:"16px 0 8px" }}>Ready to upgrade?</h3>
            <p style={{ color:"#8A8070", fontSize:14, lineHeight:1.7, marginBottom:22 }}>Contact the owner directly to upgrade your plan. We set you up within 24 hours.</p>
            <div style={{ background:"#1a1200", border:"1px solid #F59E0B33", borderRadius:12, padding:"14px 16px", marginBottom:20 }}>
              <div style={{ color:"#F59E0B", fontSize:11, fontFamily:"'JetBrains Mono',monospace", letterSpacing:1.5, marginBottom:8 }}>CONTACT OWNER</div>
              <div style={{ color:"#FAF7F2", fontSize:14, lineHeight:1.8 }}>
                📱 WhatsApp: <strong>+260 97 XXX XXXX</strong><br/>
                📧 Email: <strong>owner@instoreai.zm</strong>
              </div>
            </div>
            <button onClick={()=>setModal(false)} style={{ width:"100%", padding:"13px 0", background:"linear-gradient(135deg,#F59E0B,#D97706)", border:"none", borderRadius:10, color:"#0C0A08", fontWeight:800, fontSize:14 }}>
              Got It — Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────
export default function App() {
  const [screen,setScreen]=useState("landing");
  const [user,setUser]=useState(null);

  function handleAuth(u){ setUser(u); setScreen("dashboard"); }

  return (
    <>
      <style>{CSS}</style>
      {screen==="landing"   && <Landing   onLogin={()=>setScreen("login")}  onSignup={()=>setScreen("signup")} />}
      {screen==="login"     && <Auth mode="login"  onDone={handleAuth} onToggle={()=>setScreen("signup")} />}
      {screen==="signup"    && <Auth mode="signup" onDone={handleAuth} onToggle={()=>setScreen("login")} />}
      {screen==="dashboard" && <Dashboard user={user} onLogout={()=>{setUser(null);setScreen("landing");}} />}
    </>
  );
}
