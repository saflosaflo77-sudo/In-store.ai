# InStore AI 🛒
**Know Your Queue. Grow Your Store.**

AI-powered queue intelligence for Zambian retail stores.
Built for Ndola, Copperbelt. Owned by you.

---

## What This App Does
- Shows live queue levels for any store
- Predicts busy hours using AI
- Sends WhatsApp alerts to customers
- Gives managers instant AI recommendations
- Multi-store dashboard
- Billing & subscription management

---

## Deploy in 3 Steps (Free)

### Step 1 — Upload to GitHub
1. Go to https://github.com and create a free account
2. Click "New repository" → name it `instore-ai` → Create
3. Click "uploading an existing file"
4. Drag ALL these files in (keep the folder structure)
5. Click "Commit changes"

### Step 2 — Deploy on Vercel
1. Go to https://vercel.com → sign up with GitHub
2. Click "Add New Project" → select `instore-ai`
3. Leave all settings default → click "Deploy"
4. Your live link appears in ~60 seconds
   Example: https://instore-ai.vercel.app

### Step 3 — Get Paid (Flutterwave)
1. Go to https://flutterwave.com/zm → create business account
2. Add your MTN Mobile Money or bank account
3. Create a payment link for each plan:
   - Starter: $99/month
   - Growth: $249/month  
   - Enterprise: $599/month
4. Replace the contact info in the Upgrade modal with your Flutterwave payment links

---

## Add Your Contact Info
In src/App.jsx, search for "owner@instoreai.zm" and replace with your real email.
Search for "+260 97 XXX XXXX" and replace with your real WhatsApp number.

---

## Get a Domain (~$10/year)
1. Go to https://namecheap.com
2. Search "instoreai.com" or "instoreai.co.zm"
3. Buy it → connect in Vercel: Settings → Domains → Add

---

## Revenue Model
| Clients | Monthly Income |
|---------|---------------|
| 1 store | $99/mo |
| 5 stores | $495/mo |
| 10 stores | $990/mo |
| 20 stores | $1,980/mo |

---

## Owner
This app belongs to you. All rights reserved.
Built with InStore AI · Ndola, Zambia 🇿🇲
